import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";

dotenv.config();

// ─── VALIDAR VARIABLES DE ENTORNO ────────────────────────────────────────────
const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_KEY", "CLAUDE_API_KEY"];
REQUIRED_ENV.forEach((key) => {
  if (!process.env[key]) {
    console.error(`❌ Falta variable de entorno: ${key}`);
    process.exit(1);
  }
});

// ─── SUPABASE ─────────────────────────────────────────────────────────────────
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// ─── EXPRESS ──────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────────
app.get("/", (req, res) => res.json({ status: "OK" }));

// ─── TEST CONEXIÓN SUPABASE ───────────────────────────────────────────────────
// GET /api/test-db  → para verificar que Supabase responde correctamente
app.get("/api/test-db", async (req, res) => {
  const { data, error } = await supabase.from("users").select("id, email").limit(3);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true, muestra: data });
});

// ─── LOGIN ────────────────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  try {
    let { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email y password requeridos" });
    }

    email    = email.trim().toLowerCase();
    password = password.trim();

    console.log(`[LOGIN] Intentando: ${email}`);

    // Buscar usuario por email (case-insensitive)
    const { data: user, error } = await supabase
      .from("users")
      .select("*")
      .ilike("email", email)
      .single();

    if (error || !user) {
      console.log("[LOGIN] Usuario no encontrado");
      return res.status(401).json({ error: "Credenciales inválidas" });
    }

    // Validar password
    // NOTA: idealmente deberías usar bcrypt. Si las passwords en DB son texto plano,
    // esto funciona, pero es inseguro. Migrá a hash cuando puedas.
    if (user.password !== password) {
      console.log("[LOGIN] Password incorrecto");
      return res.status(401).json({ error: "Credenciales inválidas" });
    }

    // Validar suscripción
    const now = new Date();
    const exp = user.fecha_expiracion ? new Date(user.fecha_expiracion) : null;

    if (exp && now > exp) {
      console.log(`[LOGIN] Suscripción vencida: ${exp}`);
      return res.status(403).json({ error: "Suscripción vencida" });
    }

    // Alerta de vencimiento próximo (72hs)
    let alertaVencimiento = null;
    if (exp) {
      const horasRestantes = (exp - now) / (1000 * 60 * 60);
      if (horasRestantes <= 72) {
        const horas = Math.floor(horasRestantes);
        alertaVencimiento = `Tu suscripción vence en ${horas} horas`;
        console.log(`[LOGIN] Alerta: ${alertaVencimiento}`);
      }
    }

    // No mandar la password al frontend nunca
    const { password: _, ...userSafe } = user;

    console.log(`[LOGIN] OK: ${email} | role: ${user.role}`);
    res.json({
      success: true,
      user: userSafe,
      alertaVencimiento,
    });

  } catch (err) {
    console.error("[LOGIN] Error:", err);
    res.status(500).json({ error: "Error del servidor" });
  }
});

// ─── GUARDAR SESIÓN DE ENTRENAMIENTO ─────────────────────────────────────────
app.post("/api/sesion", async (req, res) => {
  try {
    const { userId, sesion } = req.body;

    if (!userId || !sesion) {
      return res.status(400).json({ error: "userId y sesion requeridos" });
    }

    const { data, error } = await supabase
      .from("sesiones")
      .insert([{ user_id: userId, ...sesion, created_at: new Date().toISOString() }])
      .select()
      .single();

    if (error) {
      console.error("[SESION] Error al guardar:", error.message);
      return res.status(500).json({ error: error.message });
    }

    res.json({ success: true, sesion: data });

  } catch (err) {
    console.error("[SESION] Error:", err);
    res.status(500).json({ error: "Error del servidor" });
  }
});

// ─── OBTENER HISTORIAL DE SESIONES ───────────────────────────────────────────
app.get("/api/sesiones/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const limit = parseInt(req.query.limit) || 30;

    const { data, error } = await supabase
      .from("sesiones")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) return res.status(500).json({ error: error.message });

    res.json({ success: true, sesiones: data });

  } catch (err) {
    console.error("[HISTORIAL] Error:", err);
    res.status(500).json({ error: "Error del servidor" });
  }
});

// ─── COACH IA ─────────────────────────────────────────────────────────────────
app.post("/api/coach", async (req, res) => {
  try {
    const { system, userMsg } = req.body;

    if (!system || !userMsg) {
      return res.status(400).json({ error: "system y userMsg requeridos" });
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.CLAUDE_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1200,
        system,
        messages: [{ role: "user", content: userMsg }],
      }),
    });

    const data = await response.json();

    if (data.error) {
      console.error("[COACH] API error:", data.error);
      return res.status(500).json({ error: data.error.message });
    }

    const text = data.content?.map((b) => b.text || "").join("\n") || "";
    res.json({ success: true, text });

  } catch (err) {
    console.error("[COACH] Error:", err);
    res.status(500).json({ error: "Error del servidor" });
  }
});

// ─── START ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});
